# rvs19-spa-dz-01
Domaća zadaća 01 za SPA u 2019.

Koristi SFML verziju Visual C++ 15 (2017) - 64-bit sa https://www.sfml-dev.org/download/sfml/2.5.1/
